package org.sinytra.fabric.model_loading_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_model_loading_api_v1";  
    public static final String RAW_MOD_ID = "fabric-model-loading-api-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        // Initialize client entrypoints
        if (net.neoforged.fml.loading.FMLEnvironment.getDist().isClient()) {
            new net.fabricmc.fabric.impl.client.model.loading.CustomUnbakedBlockStateModelInit().onInitializeClient();
        }
    }
}