package org.sinytra.fabric.loot_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_loot_api_v3";  
    public static final String RAW_MOD_ID = "fabric-loot-api-v3";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
    }
}