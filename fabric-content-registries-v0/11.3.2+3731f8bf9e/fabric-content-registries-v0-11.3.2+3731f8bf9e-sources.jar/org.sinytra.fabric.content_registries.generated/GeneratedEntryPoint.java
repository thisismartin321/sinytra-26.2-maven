package org.sinytra.fabric.content_registries.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_content_registries_v0";  
    public static final String RAW_MOD_ID = "fabric-content-registries-v0";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
    }
}