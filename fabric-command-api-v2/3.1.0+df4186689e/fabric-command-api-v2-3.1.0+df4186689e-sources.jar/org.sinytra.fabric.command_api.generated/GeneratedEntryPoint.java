package org.sinytra.fabric.command_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_command_api_v2";  
    public static final String RAW_MOD_ID = "fabric-command-api-v2";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.command.FabricCommandApiV2().onInitialize();
        
        // Initialize client entrypoints
        if (net.neoforged.fml.loading.FMLEnvironment.getDist().isClient()) {
            new net.fabricmc.fabric.impl.command.client.FabricCommandApiV2Client().onInitializeClient();
        }
    }
}