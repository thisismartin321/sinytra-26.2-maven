package org.sinytra.fabric.lifecycle_events.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_lifecycle_events_v1";  
    public static final String RAW_MOD_ID = "fabric-lifecycle-events-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.event.lifecycle.LifecycleEventsImpl().onInitialize();
        
        // Initialize client entrypoints
        if (net.neoforged.fml.loading.FMLEnvironment.getDist().isClient()) {
            new net.fabricmc.fabric.impl.client.event.lifecycle.ClientLifecycleEventsImpl().onInitializeClient();
        }
    }
}