package org.sinytra.fabric.networking_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_networking_api_v1";  
    public static final String RAW_MOD_ID = "fabric-networking-api-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        // Initialize client entrypoints
        if (net.neoforged.fml.loading.FMLEnvironment.getDist().isClient()) {
            net.fabricmc.fabric.impl.networking.client.ClientNetworkingImpl.clientInit();
        }
    }
}