/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.networking;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import io.netty.channel.ChannelFutureListener;
import net.neoforged.neoforge.network.payload.MinecraftRegisterPayload;
import net.neoforged.neoforge.network.payload.MinecraftUnregisterPayload;
import net.neoforged.neoforge.network.registration.ChannelAttributes;
import org.jspecify.annotations.Nullable;

import net.minecraft.network.Connection;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.RunningOnDifferentThreadException;

import net.fabricmc.fabric.api.networking.v1.PacketSender;

/**
 * A network addon which is aware of the channels the other side may receive.
 *
 * @param <H> the channel handler type
 */
public abstract class AbstractChanneledNetworkAddon<H> extends AbstractNetworkAddon<H> implements PacketSender, CommonPacketHandler {
	// The maximum number of channels that a connecting client can register.
	private static final int MAX_CHANNELS = Integer.getInteger("fabric.networking.maxChannels", 8192);
	// The maximum length of a channel name a connecting client can use, 128 is the default and minimum value.
	private static final int MAX_CHANNEL_NAME_LENGTH = Math.max(Integer.getInteger("fabric.networking.maxChannelNameLength", GlobalReceiverRegistry.DEFAULT_CHANNEL_NAME_MAX_LENGTH), GlobalReceiverRegistry.DEFAULT_CHANNEL_NAME_MAX_LENGTH);

	protected final Connection connection;
	protected final GlobalReceiverRegistry<H> receiver;
	protected final Set<Identifier> sendableChannels;

	protected int commonVersion = -1;

	protected AbstractChanneledNetworkAddon(GlobalReceiverRegistry<H> receiver, Connection connection, String description) {
		super(receiver, description);
		this.connection = connection;
		this.receiver = receiver;
		this.sendableChannels = Collections.synchronizedSet(new HashSet<>());
	}
	
	public @Nullable PayloadTypeRegistryImpl<?> getPayloadTypeRegistry() {
		return this.receiver.getPayloadTypeRegistry();
	}

	protected void registerPendingChannels(ChannelInfoHolder holder, ConnectionProtocol state) {
		if (this.connection.channel() == null) {
			return;
		}

		final Collection<Identifier> pending = ChannelAttributes.getOrCreateCommonChannels(this.connection, state);

		if (!pending.isEmpty()) {
			register(new ArrayList<>(pending));
		}
	}

	// always supposed to handle async!
	public boolean handle(CustomPacketPayload payload) {
		final Identifier channelName = payload.type().id();
		this.logger.debug("Handling inbound packet from channel with name \"{}\"", channelName);

		// Handle reserved packets
		if (payload instanceof MinecraftRegisterPayload registrationPayload) {
			this.receiveRegistration(true, new RegistrationPayload(RegistrationPayload.REGISTER,
					new ArrayList<>(registrationPayload.newChannels())));
			return false; // Propagate to Neo
		}
		
		if (payload instanceof MinecraftUnregisterPayload unregisterPayload) {
			this.receiveRegistration(false, new RegistrationPayload(RegistrationPayload.UNREGISTER,
					new ArrayList<>(unregisterPayload.forgottenChannels())));
			return false; // Propagate to Neo
		}

		@Nullable H handler = this.getHandler(channelName);

		if (handler == null) {
			return false;
		}

		if (!isOnReceiveThread()) {
			throw RunningOnDifferentThreadException.RUNNING_ON_DIFFERENT_THREAD;
		}

		try {
			this.receive(handler, payload);
		} catch (Throwable ex) {
			this.logger.error("Encountered exception while handling in channel with name \"{}\"", channelName, ex);
			throw ex;
		}

		return true;
	}

	protected abstract boolean isOnReceiveThread();

	protected abstract void receive(H handler, CustomPacketPayload payload);

	protected void sendInitialChannelRegistrationPacket() {
		final CustomPacketPayload payload = createRegistrationPayload(RegistrationPayload.REGISTER, this.getReceivableChannels());

		if (payload != null) {
			this.sendPacket(payload);
		}
	}

	@Nullable
	protected CustomPacketPayload createRegistrationPayload(CustomPacketPayload.Type<RegistrationPayload> type, Set<Identifier> channels) {
		if (channels.isEmpty()) {
			return null;
		}

		return type == RegistrationPayload.REGISTER ? new MinecraftRegisterPayload(channels)
				: new MinecraftUnregisterPayload(channels);
	}

	// wrap in try with res (buf)
	protected void receiveRegistration(boolean register, RegistrationPayload payload) {
		if (register) {
			register(payload.channels());
		} else {
			unregister(payload.channels());
		}
	}

	void register(List<Identifier> ids) {
		ids.forEach(this::registerChannel);
		schedule(() -> this.invokeRegisterEvent(ids));
	}

	private void registerChannel(Identifier id) {
		if (this.sendableChannels.size() >= MAX_CHANNELS) {
			throw new IllegalArgumentException("Cannot register more than " + MAX_CHANNELS + " channels");
		}

		if (id.toString().length() > MAX_CHANNEL_NAME_LENGTH) {
			throw new IllegalArgumentException("Channel name is too long");
		}

		this.sendableChannels.add(id);
		onUpdateSendableChannels();
	}

	void unregister(List<Identifier> ids) {
		this.sendableChannels.removeAll(ids);
		onUpdateSendableChannels();
		schedule(() -> this.invokeUnregisterEvent(ids));
	}

	protected void onUpdateSendableChannels() {
		
	}

	@Override
	public void sendPacket(Packet<?> packet, ChannelFutureListener callback) {
		Objects.requireNonNull(packet, "Packet cannot be null");

		this.connection.send(packet, callback);
	}

	@Override
	public void disconnect(Component disconnectReason) {
		Objects.requireNonNull(disconnectReason, "Disconnect reason cannot be null");

		this.connection.disconnect(disconnectReason);
	}

	/**
	 * Schedules a task to run on the main thread.
	 */
	protected abstract void schedule(Runnable task);

	protected abstract void invokeRegisterEvent(List<Identifier> ids);

	protected abstract void invokeUnregisterEvent(List<Identifier> ids);

	public Set<Identifier> getSendableChannels() {
		return Collections.unmodifiableSet(this.sendableChannels);
	}

	// Common packet handlers

	@Override
	public void onCommonVersionPacket(int negotiatedVersion) {
		// We only support version 1 for now
		if (negotiatedVersion != 1) {
			throw new UnsupportedOperationException("Unsupported common packet version: " + negotiatedVersion);
		}

		commonVersion = negotiatedVersion;
		this.logger.debug("Negotiated common packet version {}", commonVersion);
	}

	@Override
	public void onCommonRegisterPacket(CommonRegisterPayload payload) {
		if (payload.version() != getNegotiatedVersion()) {
			throw new IllegalStateException("Negotiated common packet version: %d but received packet with version: %d".formatted(commonVersion, payload.version()));
		}

		final String currentPhase = getProtocol();

		if (currentPhase == null) {
			// We don't support receiving the register packet during this phase. See getPhase() for supported phases.
			// The normal case where the play channels are sent during configuration is handled in the client/common configuration packet handlers.
			logger.warn("Received common register packet for protocol {} in protocol: {}", payload.protocol(), receiver.getProtocol());
			return;
		}

		if (!payload.protocol().equals(currentPhase)) {
			// We need to handle receiving the play phase during configuration!
			throw new IllegalStateException("Register packet received for protocol (%s) on handler for protocol(%s)".formatted(payload.protocol(), currentPhase));
		}

		register(new ArrayList<>(payload.channels()));
	}

	@Override
	public CommonRegisterPayload createRegisterPayload() {
		return new CommonRegisterPayload(getNegotiatedVersion(), getProtocol(), this.getReceivableChannels());
	}

	@Override
	public int getNegotiatedVersion() {
		if (commonVersion == -1) {
			throw new IllegalStateException("Not yet negotiated common packet version");
		}

		return commonVersion;
	}

	@Nullable
	private String getProtocol() {
		return switch (receiver.getProtocol()) {
		case PLAY -> CommonRegisterPayload.PLAY_PROTOCOL;
		case CONFIGURATION -> CommonRegisterPayload.CONFIGURATION_PROTOCOL;
		default -> null; // We don't support receiving this packet on any other phase
		};
	}
}
