package org.sinytra.fabric.convention_tags.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_convention_tags_v2";  
    public static final String RAW_MOD_ID = "fabric-convention-tags-v2";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.tag.convention.v2.TranslationConventionLogWarnings().onInitialize();
    }
}