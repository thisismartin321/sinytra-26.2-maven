/*
 * Copyright 2016 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.loader.impl.discovery;

import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.Version;
import net.fabricmc.loader.api.metadata.*;
import net.fabricmc.loader.api.metadata.CustomValue.CvType;
import net.fabricmc.loader.impl.Constants;
import net.fabricmc.loader.impl.metadata.AbstractModMetadata;
import net.fabricmc.loader.impl.metadata.EntrypointMetadata;
import net.fabricmc.loader.impl.metadata.LoaderModMetadata;
import net.fabricmc.loader.impl.metadata.NestedJarEntry;

import java.util.*;

public class FMLMetadataWrapper extends AbstractModMetadata implements LoaderModMetadata {
    private final ModMetadata parent;
    private Version version;
    private Collection<ModDependency> dependencies;
    private final Map<String, List<EntrypointMetadata>> entrypoints;

    public FMLMetadataWrapper(ModMetadata parent) {
        this.parent = parent;

        version = parent.getVersion();
        dependencies = parent.getDependencies();
        entrypoints = readEntrypoints(parent);
    }

    @Override
    public String getType() {
        return parent.getType();
    }

    @Override
    public String getId() {
        return parent.getId();
    }

    @Override
    public Collection<String> getProvides() {
        return parent.getProvides();
    }

    @Override
    public Version getVersion() {
        return version;
    }

    @Override
    public void setVersion(Version version) {
        this.version = version;
    }

    @Override
    public ModEnvironment getEnvironment() {
        return parent.getEnvironment();
    }

    @Override
    public Collection<ModDependency> getDependencies() {
        return dependencies;
    }

    @Override
    public void setDependencies(Collection<ModDependency> dependencies) {
        this.dependencies = Collections.unmodifiableCollection(dependencies);
    }

    @Override
    public String getName() {
        return parent.getName();
    }

    @Override
    public String getDescription() {
        return parent.getDescription();
    }

    @Override
    public Collection<Person> getAuthors() {
        return parent.getAuthors();
    }

    @Override
    public Collection<Person> getContributors() {
        return parent.getContributors();
    }

    @Override
    public ContactInformation getContact() {
        return parent.getContact();
    }

    @Override
    public Collection<String> getLicense() {
        return parent.getLicense();
    }

    @Override
    public Optional<String> getIconPath(int size) {
        return parent.getIconPath(size);
    }

    @Override
    public boolean containsCustomValue(String key) {
        return parent.containsCustomValue(key);
    }

    @Override
    public CustomValue getCustomValue(String key) {
        return parent.getCustomValue(key);
    }

    @Override
    public Map<String, CustomValue> getCustomValues() {
        return parent.getCustomValues();
    }

    @Override
    public int getSchemaVersion() {
        return Integer.MAX_VALUE;
    }

    @Override
    public Map<String, String> getLanguageAdapterDefinitions() {
        return Collections.emptyMap();
    }

    @Override
    public Collection<NestedJarEntry> getJars() {
        return Collections.emptyList();
    }

    @Override
    public Collection<String> getMixinConfigs(EnvType type) {
        return Collections.emptyList();
    }

    @Override
    public String getClassTweaker() {
        return null;
    }

    @Override
    public boolean loadsInEnvironment(EnvType type) {
        return true;
    }

    @Override
    public Collection<String> getOldInitializers() {
        return Collections.emptyList();
    }

    @Override
    public List<EntrypointMetadata> getEntrypoints(String type) {
        if (type == null) {
            return Collections.emptyList();
        }

        final List<EntrypointMetadata> entrypoints = this.entrypoints.get(type);

        if (entrypoints != null) {
            return entrypoints;
        }

        return Collections.emptyList();
    }

    @Override
    public Collection<String> getEntrypointKeys() {
        return this.entrypoints.keySet();
    }

    @Override
    public void emitFormatWarnings() {
    }

    private static Map<String, List<EntrypointMetadata>> readEntrypoints(ModMetadata metadata) {
        Map<String, List<EntrypointMetadata>> entrypoints = new HashMap<>();

        CustomValue entrypointsValue = metadata.getCustomValue(Constants.ENTRYPOINTS);
        if (entrypointsValue != null) {
            entrypointsValue.getAsObject().forEach(entry -> {
                String key = entry.getKey();
                List<EntrypointMetadata> values = entrypoints.computeIfAbsent(key, k -> new ArrayList<>());

                entry.getValue().getAsArray().forEach(value -> {
                    if (value.getType() == CvType.STRING) {
                        values.add(new SimpleEntrypointMetadata("default", value.getAsString()));
                    } else if (value.getType() == CvType.OBJECT) {
                        String adapter = value.getAsObject().get("adapter").getAsString();
                        String entryValue = value.getAsObject().get("value").getAsString();
                        values.add(new SimpleEntrypointMetadata(adapter, entryValue));
                    }
                });
            });
        }

        return entrypoints;
    }

    record SimpleEntrypointMetadata(String adapter, String value) implements EntrypointMetadata {
        @Override
        public String getAdapter() {
            return adapter;
        }

        @Override
        public String getValue() {
            return value;
        }
    }
}
