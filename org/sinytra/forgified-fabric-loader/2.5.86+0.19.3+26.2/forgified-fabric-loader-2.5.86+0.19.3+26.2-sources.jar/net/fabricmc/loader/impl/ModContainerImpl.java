/*
 * Copyright 2016 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.loader.impl;

import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModOrigin;
import net.fabricmc.loader.impl.discovery.FMLMetadataWrapper;
import net.fabricmc.loader.impl.metadata.LoaderModMetadata;
import net.fabricmc.loader.impl.metadata.ModOriginImpl;
import net.neoforged.neoforgespi.language.IModInfo;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

@SuppressWarnings("deprecation")
public class ModContainerImpl extends net.fabricmc.loader.ModContainer {
    private final IModInfo modInfo;
    private final LoaderModMetadata metadata;
    private final ModOrigin origin;
    private final Collection<String> childModIds;

    public ModContainerImpl(IModInfo modInfo) {
        this(modInfo, Optional.ofNullable((LoaderModMetadata) modInfo.getOwningFile().getFileProperties().get(Constants.METADATA))
            .orElseGet(() -> new FMLMetadataWrapper(new FMLModMetadata(modInfo))));
    }

    public ModContainerImpl(IModInfo modInfo, LoaderModMetadata metadata) {
        this.modInfo = modInfo;
        this.metadata = metadata;
        this.origin = new ModOriginImpl(List.of(this.modInfo.getOwningFile().getFile().getFilePath()));
        this.childModIds = modInfo.getOwningFile().getMods().stream().filter(other -> other != modInfo).map(IModInfo::getDisplayName).collect(Collectors.toSet());
    }

    @Override
    public LoaderModMetadata getMetadata() {
        return this.metadata;
    }

    @Override
    public ModOrigin getOrigin() {
        return origin;
    }

    @Override
    public List<Path> getCodeSourcePaths() {
        return this.modInfo.getOwningFile().getFile().getContents().getContentRoots()
            .stream()
            .toList();
    }

    @Override
    public Path getRootPath() {
        return getRootPaths().stream().findFirst().orElse(null);
    }

    @Override
    public List<Path> getRootPaths() {
        return this.modInfo.getOwningFile().getFile().getContents().getContentRoots()
            .stream()
            .map(ModContainerImpl::createInnerPath)
            .toList();
    }

    @Override
    public Path getPath(String file) {
        Optional<Path> res = findPath(file);
        if (res.isPresent()) return res.get();

        List<Path> roots = getRootPaths();

        if (!roots.isEmpty()) {
            Path root = roots.getFirst();

            return root.resolve(file.replace("/", root.getFileSystem().getSeparator()));
        } else {
            return Paths.get(".").resolve("missing_ae236f4970ce").resolve(file.replace('/', File.separatorChar));
        }
    }

    @Override
    public Optional<ModContainer> getContainingMod() {
        return Optional.empty();
    }

    @Override
    public Collection<ModContainer> getContainedMods() {
        if (this.childModIds.isEmpty()) return Collections.emptyList();

        List<ModContainer> ret = new ArrayList<>(this.childModIds.size());

        for (String id : this.childModIds) {
            FabricLoaderImpl.INSTANCE.getModContainer(id).ifPresent(ret::add);
        }

        return ret;
    }

    @Deprecated
    @Override
    public LoaderModMetadata getInfo() {
        return getMetadata();
    }

    @Override
    public String toString() {
        return String.format("%s %s", this.modInfo.getModId(), this.modInfo.getVersion());
    }

    private static Path createInnerPath(Path path) {
        if (Files.isDirectory(path)) {
            return path;
        }
        try {
            return FileSystems.newFileSystem(path).getRootDirectories().iterator().next();
        } catch (Exception e) {
            return path;
        }
    }
}
