package org.sinytra.fabric.rendering_fluids.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_rendering_fluids_v1";  
    public static final String RAW_MOD_ID = "fabric-rendering-fluids-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
    }
}