package org.sinytra.fabric.registry_sync.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_registry_sync_v0";  
    public static final String RAW_MOD_ID = "fabric-registry-sync-v0";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.registry.sync.FabricRegistryInit().onInitialize();
    }
}