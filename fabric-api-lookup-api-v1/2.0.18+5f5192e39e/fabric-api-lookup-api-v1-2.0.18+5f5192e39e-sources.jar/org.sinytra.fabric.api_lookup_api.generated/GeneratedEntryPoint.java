package org.sinytra.fabric.api_lookup_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_api_lookup_api_v1";  
    public static final String RAW_MOD_ID = "fabric-api-lookup-api-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.lookup.ApiLookupImpl().onInitialize();
    }
}