package org.sinytra.fabric.events_interaction.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_events_interaction_v0";  
    public static final String RAW_MOD_ID = "fabric-events-interaction-v0";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.event.interaction.InteractionEventsRouter().onInitialize();
    }
}