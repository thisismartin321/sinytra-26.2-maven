package org.sinytra.fabric.resource_loader_v0.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_resource_loader_v0";  
    public static final String RAW_MOD_ID = "fabric-resource-loader-v0";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
    }
}