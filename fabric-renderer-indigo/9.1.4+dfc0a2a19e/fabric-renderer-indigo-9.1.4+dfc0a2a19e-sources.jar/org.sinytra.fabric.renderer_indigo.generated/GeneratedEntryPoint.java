package org.sinytra.fabric.renderer_indigo.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_renderer_indigo";  
    public static final String RAW_MOD_ID = "fabric-renderer-indigo";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        // Initialize client entrypoints
        if (net.neoforged.fml.loading.FMLEnvironment.getDist().isClient()) {
            new net.fabricmc.fabric.impl.client.indigo.Indigo().onInitializeClient();
        }
    }
}