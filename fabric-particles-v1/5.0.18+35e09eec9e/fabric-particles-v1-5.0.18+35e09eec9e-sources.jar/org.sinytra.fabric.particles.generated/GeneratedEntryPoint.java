package org.sinytra.fabric.particles.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_particles_v1";  
    public static final String RAW_MOD_ID = "fabric-particles-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
    }
}