package org.sinytra.fabric.data_attachment_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_data_attachment_api_v1";  
    public static final String RAW_MOD_ID = "fabric-data-attachment-api-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.attachment.AttachmentEntrypoint().onInitialize();
    }
}