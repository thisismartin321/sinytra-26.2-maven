package org.sinytra.fabric.recipe_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_recipe_api_v1";  
    public static final String RAW_MOD_ID = "fabric-recipe-api-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.recipe.ingredient.CustomIngredientInit().onInitialize();
        new net.fabricmc.fabric.impl.recipe.sync.RecipeSyncImpl().onInitialize();
    }
}