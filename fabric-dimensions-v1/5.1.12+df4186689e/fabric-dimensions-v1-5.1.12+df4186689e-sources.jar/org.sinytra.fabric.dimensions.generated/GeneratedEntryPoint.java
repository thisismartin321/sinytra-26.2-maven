package org.sinytra.fabric.dimensions.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_dimensions_v1";  
    public static final String RAW_MOD_ID = "fabric-dimensions-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.dimension.DimensionModificationImpl().onInitialize();
    }
}